<template>
    <div>
      <!-- 顶部搜索栏 -->
      <div id="index_search">
        <form action="#" method="post">
          <input type="text" placeholder="请输入电影名称或主演" class="search" v-model="val">
        </form>
        <span class="iconfont">&#xe633;</span>
        <a href="#" class="index_message iconfont">&#xe630;</a>
      </div>
    </div>
</template>

<script>
    export default {
      data(){
        return{
          val:""
        }
      }
    }
</script>

<style>
  html,body{
    width: 100%;
    height: 100%;
  }
  /*顶部拦*/
  #index_search{width: 7.5rem;height: 0.8rem;background: #BFDFDA;opacity:1;position: fixed
  ;top: 0; z-index: 5; left: 50%;  transform: translate(-50%);}
  /*搜索框*/
  #index_search form{width: 87%;height: 0.44rem;display: block;border-radius: 0.2rem;background: #fff;
    position: absolute;top:0.18rem;left: 0.3rem;overflow: hidden;}
  #index_search span.iconfont{position: absolute;top:0.23rem;left: 0.43rem;z-index: 11;font-size: 0.3rem;color: #ccc}
  #index_search form input{width: 90%;height: 100%;display: block;position: relative;left:0.53rem;background: #fff;
    right:0.8rem;font-size: 0.2rem;z-index: 1001;border-radius: 0.05rem;border: 0;outline: none;}
  #index_search .index_message{width: 0.36rem;height: 0.26rem;color: #FFF;font-size: 0.3rem;line-height: 0.19rem;text-align: center;position: absolute;right: 0.15rem;top: 0.32rem;}

</style>
