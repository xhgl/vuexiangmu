<template>
    <div>
      <!-- 顶部搜索栏 -->
      <div id="index_search">
        <form action="#">
          <input type="text" placeholder="请输入电影名称或主演" class="search" v-model="val" @keyup.enter="getData">
        </form>
        <span class="iconfont">&#xe633;</span>
        <a href="#" class="index_message iconfont">&#xe630;</a>
      </div>

      <div id="content">
        <router-link  :to="{name: 'detils', params: {cid: data}}" v-for="(data,index) in datas" :key="index" >
             <div class="list"  >
          <img :src="data.images.large" alt="">
          <div class="right">
            <span>《{{data.title}}》</span>
           <span>类型: {{data.genres[0]}}/{{data.genres[1]}}/{{data.genres[2]}}</span>
            <span>导演:{{data.directors[0].name}}</span>
            <span>主演:{{data.casts[0].name}}/{{data.casts[1].name}}/{{data.casts[2].name}}</span>
          </div>

          <div class="main-right">
            <h4>豆瓣评分</h4>
            <span class="rating-left" >{{data.rating.average}}</span>
            <span class="rating-right">
                    <i class="rating-bg" ref="avg"></i>
                    <i class="pingjia">20评价</i>
                  </span>
          </div>
        </div>
        </router-link>

        <div class="more">
          <span>查看更多</span>
          <span @click="backTop">返回顶部</span>
        </div>

      </div>

      <Footer></Footer>
    </div>
</template>

<script>
  import Footer from "./footer.vue"
  import axios from "axios"
    export default {
      data(){
        return{
          datas:[],
          num:[],
          val:"",
          a:[]

        }
      },
      components:{
        Footer,
      },
      created(){
        let that = this;
        axios({
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
          type:"get",
          url:"static/data/movie_in_theaters.json",
        }).then(function (res) {
          that.datas = res.data.subjects;
//             that.stars = res.data.subjects.rating;
          for( let i = 0 ;i<that.datas.length;i++){
            that.num.push(that.datas[i].rating.average);
          };
//                   that.star();

               console.log(that.datas);
        },function (err) {

        });

      },
      methods:{
//        搜索框
            getData(){
//              console.log(this.datas[0].title);
              for(let i =0;i<this.datas.length;i++){
                  if(this.val ==this.datas[i].title||this.val== this.datas[i].directors[0].name){
                            let a = this.datas[i];
                         this.datas.unshift(a);
                         console.log(this.datas);
//                      console.log(this.datas[i].title);
                        break;
                  }else{
                    console.log("000");
                    break;
                  }
              }

            },
//        返回顶部
        backTop(){
          document.documentElement.scrollTop= 0;
        }

      },
//      评分星星
      updated(){
        for (let j = 0; j < this.num.length; j++) {
          let y = parseInt(10 - Number(this.num[j])) * -15 + "px";
//          console.log(y);
          this.$refs.avg[j].style.backgroundPosition="0px "+y;

        }
      }
    }
</script>

<style>
  /*顶部拦*/
  #index_search{width: 7.5rem;height: 0.8rem;background: #BFDFDA;opacity:1;position: fixed
  ;top: 0; z-index: 5; left: 50%;  transform: translate(-50%);}
  /*搜索框*/
  #index_search form{width: 87%;height: 0.44rem;display: block;border-radius: 0.2rem;background: #fff;
    position: absolute;top:0.18rem;left: 0.3rem;overflow: hidden;}
  #index_search span.iconfont{position: absolute;top:0.23rem;left: 0.43rem;z-index: 11;font-size: 0.3rem;color: #ccc}
  #index_search form input{width: 90%;height: 100%;display: block;position: relative;left:0.53rem;background: #fff;
    right:0.8rem;font-size: 0.2rem;z-index: 1001;border-radius: 0.05rem;border: 0;outline: none;}
  #index_search .index_message{width: 0.36rem;height: 0.26rem;color: #FFF;font-size: 0.3rem;line-height: 0.19rem;text-align: center;position: absolute;right: 0.15rem;top: 0.32rem;}



  #content{
    width:7.5rem;
    height: 70rem;
    margin: 0 auto;
    background: #fff;
    margin-top: 0.8rem;
  }
  a{
    color: gray;
  }
  #content .list{
    width: 100%;
    height: 3.4rem;
    /*background: deepskyblue;*/
    padding: 0.2rem;
    position: relative;
    border-bottom: 1px solid #ccc;
  }
  #content .list img{
    width: 2.8rem;
    height: 3rem;
    float: left;
    margin-right: 0.2rem;
  }
  #content .list .right{
    width: 4.2rem;
    height: 3rem;
    /*background: saddlebrown;*/
   position: absolute;
    top:0.2rem;
    right: 0.2rem;
    color:gray;

  }
  #content .list .right span:nth-child(1){
    width: 100%;
    height: 0.3rem;
    font-size: 0.22rem;
    /*background: seagreen;*/
    display: inline-block;
  }
  #content .list .right span:nth-child(2){
    font-size: 0.2rem;
    width: 100%;
    height: 0.3rem;
    padding-left: 0.12rem;
    display: inline-block;
    /*background: deeppink;*/

  }
   #content .list .right span:nth-child(3){
       width:100%;
      height: 0.5rem;
      display: inline-block;
      /*background: red;*/
     font-size: 0.2rem;
     line-height: 0.5rem;
     padding-left: 0.12rem;
    }
    #content .list .right span:nth-child(4){
      font-size: 0.2rem;
      width:100%;
      height: 0.5rem;
      display: block;
      line-height: 0.5rem;
      padding-left: 0.12rem;
      /*background: skyblue;*/
    }


    /*评分*/

  #content .list .main-right {
    float: left;
    padding-left: 0.2rem;
    position: absolute;
    right: 0.2rem;
    top:0.3rem;
  }

  #content .list .main-right h4 {
    font-size: 0.14rem;
    color: #666;
    font-style: normal;
  }

  #content .list .main-right .rating-left {
    font-size: 0.32rem;
  }

  #content .list .main-right .rating-right {

    display: inline-block;
  }

  #content .list .main-right .rating-right .rating-bg {
    width: 0.75rem;
    height: 0.15rem;
    position: relative;
    top:0.1rem;
    background: url(../assets/images/stars.png) no-repeat 0px 0px;
    display: block;
  }

  #content .list .main-right .rating-right .pingjia {
    font-style: normal;
    font-size: 0.14rem;
    color: #666;
  }
  #content .more{
    width:100%;
    height: 0.6rem;
    padding: 0px 1rem;
    margin-top: 0.5rem;
  }
  #content .more span{
    width: 50%;
    height: 100%;
    display: block;
    float: left;
    font-size: 0.2rem;
    text-align: center;
    line-height: 0.6rem;
    border: 1px solid #ccc;
  }
</style>
