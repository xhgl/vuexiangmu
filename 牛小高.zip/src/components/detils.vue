<template>
    <div>
      <!--<h3 >接收参数：{{$route.params.cid}}</h3>-->
      <!--v-show="data.cid == $route.params.cid"-->

      <div id="content">
        <div class="header">
          详情
          <span class="per_back" @click="back"></span>
        </div>

          <div class="list">

            <img :src="data.images.large" alt="">

            <div class="right">
              <span>《{{data.title}}》</span>
              <span>类型: {{data.genres[0]}}/{{data.genres[1]}}/{{data.genres[2]}}</span>
              <span>导演:{{data.directors[0].name}}</span>
              <span>时长：</span>
              <span>上映时间:{{data.year}}</span>
            </div>

            <div class="main-right">
              <h4>豆瓣评分</h4>
              <span class="rating-left" >{{data.rating.average}}</span>
              <span class="rating-right">
                      <i class="rating-bg" ref="avg"></i>
                      <i class="pingjia">20评价</i>
                    </span>
            </div>

            <div class="banner">
            <swiper :options="swiperOption">
              <swiper-slide>
                <a href="">
                      aaa
                  <span></span>
                </a>
              </swiper-slide>
              <swiper-slide>
                <a href="">
                      bbbb
                  <span></span>
                </a>
              </swiper-slide>
              <swiper-slide>
                <a href="">
                 ccccc
                  <span></span>
                </a>
              </swiper-slide>
              <swiper-slide>
                <a href="">
                  ddddd
                  <span></span>
                </a>
              </swiper-slide>

            </swiper>
            </div>


          </div>

        <div class="look">
          <span>想看</span>
          <span>评分</span>
        </div>
        <h3>主演</h3>


         <div class="footer">
           优惠购票
         </div>


      </div>

      <!--<router-view></router-view>-->

    </div>
</template>

<script>
  import axios from "axios"
  import {swiper,swiperSlide} from "vue-awesome-swiper"
  export default {
//    props:["datas"]
       data(){
          return{
            data:{},
            datas:[],
            num:[],
              swiperOption:{
                slidesPerView: 3.2,
                spaceBetween: 10,
                centeredSlides: false,
            }

          }
        },
      components:{
        swiper,
        swiperSlide
      },


      mounted(){
        let y = parseInt(10 - Number(this.data.rating.average)) * -15 + "px";
        this.$refs.avg.style.backgroundPosition="0px "+y;
      },



          created(){
//         console.log(this.$route.params.cid);
           this.data = this.$route.params.cid;
           console.log(this.data);

          let that = this;
 /*         axios({
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            type:"get",
            url:"static/data/movie_in_theaters.json",
          }).then(function (res) {
            that.datas = res.data.subjects;
    //             that.stars = res.data.subjects.rating;
            for( let i = 0 ;i<that.datas.length;i++){
              that.num.push(that.datas[i].rating.average);
            };
    //                   that.star();
          },function (err) {

          });*/

        },
        methods:{
          back(){
            window.history.back(-1)
          },
          star() {
            console.log(this.num)
            for (let j = 0; j < this.num.length; j++) {
              //    let y = parseInt(10-Number(this.num[j])) * -15 + "px";
              console.log(7);
              this.$refs.avg.style.display="none";

              //   /* $(".rating-bg").css({
              // "backgroundPosition":"0px "+y
            }
          }

        }
  }
</script>

<style>
  /*个人中心style*/
  #content {width: 100%;height:13.3rem;background: #fff;margin:0 auto;max-width:7.5rem; min-width:3.2rem;position: relative; }
  #content .header{width: 7.5rem;height: 0.8rem;background: skyblue;text-align: center;color:#fff;line-height: 0.8rem;position:fixed;top:0;font-size: 0.32rem;z-index: 1000}
  #content .header span{width: 0.26rem;height: 0.26rem;border: 0.03rem solid #FFf;display: block;position:
    absolute;top:0.26rem;left: 0.5rem;transform:rotate(-45deg);border-bottom: none;
    border-right: none;cursor: pointer;}

  #content .list{
    width: 100%;
    height: 3.4rem;
    /*background: deepskyblue;*/
    padding: 0.2rem;
    position: relative;
    margin-top: 0.8rem;
  }
  #content .list img{
    width: 2.8rem;
    height: 3rem;
    float: left;
    margin-right: 0.1rem;
  }
  #content .list .right{
    width: 4rem;
    height: 3rem;
    /*background: saddlebrown;*/
    float: left;
    position: absolute;
    right: 0.2rem;
    top:0.2rem;
    color: gray;
  }
  #content .list .right span{
    padding-left: 0.12rem;
    font-size: 0.2rem;
  }
  #content .list .right span:nth-child(1){
    width: 100%;
    height: 0.3rem;
    font-size: 0.22rem;
    /*background: seagreen;*/
    display: inline-block;
  }
  #content .list .right span:nth-child(2){
    width: 100%;
    height: 0.3rem;
    display: inline-block;
    /*background: deeppink;*/

  }
  #content .list .right span:nth-child(3){
    width:100%;
    height: 0.5rem;
    display: inline-block;
    /*background: red;*/
    line-height: 0.5rem;
  }
  #content .list .right span:nth-child(4){
    width:100%;
    height: 0.5rem;
    display: block;
    line-height: 0.5rem;
    /*background: skyblue;*/
  }
  #content .list .right span:nth-child(5){
    font-size: 0.2rem;

  }


  /*评分*/

  #content .list .main-right {
    float: left;
    padding-left: 0.2rem;
    position: absolute;
    right: 0.2rem;
    top:0.3rem;
  }

  #content .list .main-right h4 {
    font-size: 0.14rem;
    color: #666;
    font-style: normal;
  }

  #content .list .main-right .rating-left {
    font-size: 0.32rem;
  }

  #content .list .main-right .rating-right {

    display: inline-block;
  }

  #content .list .main-right .rating-right .rating-bg {
    width: 0.75rem;
    height: 0.15rem;
    position: relative;
    top:0.1rem;
    background: url(../assets/images/stars.png) no-repeat 0px 0px;
    display: block;
  }

  #content .list .main-right .rating-right .pingjia {
    font-style: normal;
    font-size: 0.14rem;
    color: #666;
  }
  #content .look{
    width: 100%;
    height: 0.8rem;
    display: flex;
    justify-content: space-around;
  }
  #content .look span{
    width: 1.5rem;
    height: 0.6rem;
    background: salmon;
    text-align: center;
    line-height: 0.6rem;
    margin-top: 0.2rem;
    border-radius: 0.1rem;
    display: block;
    float: left;
  }
  #content h3{
    padding-left: 0.2rem;
    font-weight: 400;
    font-size: 0.24rem;
    margin-top: 0.2rem;
  }
  #content .banner{
    width: 100%;
    height: 4.5rem;
    background: coral;
    margin-top: 4.6rem;
    padding: 0.1rem 0.1rem;

  }
  #content .banner a{
    width: 2rem;
    height: 3rem;
    float: left;
    border-radius: 0.2rem;
    background: #fff;
  }


  #content .footer{
    width: 100%;
    height: 0.8rem;
    background: skyblue;
    text-align: center;
    position: absolute;
    bottom:0rem;
    font-size: 0.28rem;
    line-height: 0.8rem;
  }
</style>
