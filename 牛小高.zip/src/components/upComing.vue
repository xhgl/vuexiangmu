<template>
    <div>
      <Header></Header>
      <div id="content">
        <div class="list" v-for="(data,index) in datas"  >
          <img :src="data.images.large" alt="">
          <div class="right">
            <span>《{{data.title}}》</span>
            <span>类型: {{data.genres[0]}}/{{data.genres[1]}}/{{data.genres[2]}}</span>
            <span>上映日期：{{data.year}}</span>
            <span>导演:{{data.directors[0].name}}</span>
            <span>主演:{{data.casts[0].name}}/{{data.casts[1].name}}/{{data.casts[2].name}}</span>

          </div>


        </div>
      </div>

      <Footer></Footer>
    </div>
</template>

<script>
  import Header from "./header.vue"
  import Footer from "./footer.vue"
  import axios from "axios"
    export default {
      data(){
        return{
          datas:[],
          stars:[],
          num:[],

        }
      },
      components:{
        Header,
        Footer,
      },
      created(){
        let that = this;
        axios({
          type:"get",
          url:"static/data/movie_coming_soon.json",
        }).then(function (res) {
          that.datas = res.data.subjects;
//             that.stars = res.data.subjects.rating;
          for( let i = 0 ;i<that.datas.length;i++){
            that.num.push(that.datas[i].rating.average);
          };
//                   that.star();
//               console.log(4);
        },function (err) {

        });

      },
      methods:{
        star() {
          console.log(this.num)
          for (let j = 0; j < this.num.length; j++) {
            //    let y = parseInt(10-Number(this.num[j])) * -15 + "px";
            console.log(7);
            this.$refs.avg.style.display="none";

            //   /* $(".rating-bg").css({
            // "backgroundPosition":"0px "+y
          }
        }

      },
      mounted(){
//        this.star();
      }
    }
</script>

<style>
  html,body{
    width: 100%;
    height: 100%;
  }

  #content{
    width:7.5rem;
    height: auto;
    margin: 0 auto;
    background: #fff;
    margin-top: 0.8rem;
    border-bottom: 1px solid #ccc;
  }


  #content .list{
    width: 100%;
    height: 3.4rem;
    /*background: deepskyblue;*/
    padding: 0.2rem;
    position: relative;
  }
  #content .list img{
    width: 2.8rem;
    height: 3rem;
    float: left;
    margin-right: 0.2rem;
  }
  #content .list .right {
    width: 4.1rem;
    height: 3rem;
    /*background: saddlebrown;*/
    position: absolute;
    top: 0.2rem;
    right: 0.2rem;
  }
  #content .list .right span:nth-child(1){
    width: 100%;
    height: 0.3rem;
    font-size: 0.22rem;
    /*background: seagreen;*/
    display: inline-block;
  }
  #content .list .right span:nth-child(2){
    font-size: 0.2rem;
    width: 100%;
    height: 0.3rem;
    padding-left: 0.12rem;
    display: inline-block;
    /*background: deeppink;*/

  }
  #content .list .right span:nth-child(3){
    width:100%;
    height: 0.5rem;
    display: inline-block;
    /*background: red;*/
    font-size: 0.2rem;
    line-height: 0.5rem;
    padding-left: 0.12rem;
  }
  #content .list .right span:nth-child(4){
    font-size: 0.2rem;
    width:100%;
    height: 0.5rem;
    display: block;
    line-height: 0.5rem;
    padding-left: 0.12rem;
    /*background: skyblue;*/
  }
  #content .list .right span:nth-child(5){
    font-size: 0.18rem;
    width:100%;
    height: 0.5rem;
    display: block;
    line-height: 0.5rem;
    padding-left: 0.12rem;
    /*background: saddlebrown;*/
  }




</style>
