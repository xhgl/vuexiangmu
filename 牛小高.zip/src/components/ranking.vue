<template>
    <div>
      <Header></Header>
      <div id="content">
        <div class="list" v-for="(data,index) in datas"  >
          <img :src="data.images.large" alt="">
          <div class="right">
            <span>《{{data.title}}》</span>
            <span>类型: {{data.genres[0]}}/{{data.genres[1]}}/{{data.genres[2]}}</span>
            <span>导演:{{data.directors[0].name}}</span>
            <span>主演:{{data.casts[0].name}}/{{data.casts[1].name}}/{{data.casts[2].name}}</span>
          </div>

          <div class="main-right">
            <h4>豆瓣评分</h4>
            <span class="rating-left" >{{data.rating.average}}</span>
            <span class="rating-right">
                    <i class="rating-bg" ref="avg"></i>
                    <i class="pingjia">20评价</i>
                  </span>
          </div>
        </div>
      </div>

      <Footer></Footer>
    </div>
</template>

<script>
  import Header from "./header.vue"
  import Footer from "./footer.vue"
  import axios from "axios"
  export default {
    data(){
      return{
        datas:[],
        num:[],

      }
    },
    components:{
      Header,
      Footer,
    },
    created(){
      let that = this;
      axios({
        type:"get",
        url:"static/data/movie_top250.json",
      }).then(function (res) {
        that.datas = res.data.subjects;
        for( let i = 0 ;i<that.datas.length;i++){
          that.num.push(that.datas[i].rating.average);
        };
//                   that.star();
        console.log(that.datas);
      },function (err) {

      });

    },
    updated(){
      for (let j = 0; j < this.num.length; j++) {
        let y = parseInt(10 - Number(this.num[j])) * -15 + "px";
//          console.log(y);
        this.$refs.avg[j].style.backgroundPosition="0px "+y;

      }
    }
  }
</script>

<style>
  html,body{
    width: 100%;
    height: 100%;
  }

  #content{
    width:7.5rem;
    height: auto;
    margin: 0 auto;
    background: #fff;
    margin-top: 0.8rem;
  }
  a{
    color: gray;
  }
  #content .list{
    width: 100%;
    height: 3.4rem;
    /*background: deepskyblue;*/
    padding: 0.2rem;
    position: relative;
    border-bottom: 1px solid #ccc;
  }
  #content .list img{
    width: 2.8rem;
    height: 3rem;
    float: left;
    margin-right: 0.2rem;
  }
  #content .list .right{
    width: 4.2rem;
    height: 3rem;
    /*background: saddlebrown;*/
    position: absolute;
    top:0.2rem;
    right: 0.2rem;

  }
  #content .list .right span:nth-child(1){
    width: 100%;
    height: 0.3rem;
    font-size: 0.22rem;
    /*background: seagreen;*/
    display: inline-block;
  }
  #content .list .right span:nth-child(2){
    font-size: 0.2rem;
    width: 100%;
    height: 0.3rem;
    padding-left: 0.12rem;
    display: inline-block;
    /*background: deeppink;*/

  }
  #content .list .right span:nth-child(3){
    width:100%;
    height: 0.5rem;
    display: inline-block;
    /*background: red;*/
    font-size: 0.2rem;
    line-height: 0.5rem;
    padding-left: 0.12rem;
  }
  #content .list .right span:nth-child(4){
    font-size: 0.2rem;
    width:100%;
    height: 0.5rem;
    display: block;
    line-height: 0.5rem;
    padding-left: 0.12rem;
    /*background: skyblue;*/
  }


  /*评分*/

  #content .list .main-right {
    float: left;
    padding-left: 0.2rem;
    position: absolute;
    right: 0.2rem;
    top:0.3rem;
  }

  #content .list .main-right h4 {
    font-size: 0.14rem;
    color: #666;
    font-style: normal;
  }

  #content .list .main-right .rating-left {
    font-size: 0.32rem;
  }

  #content .list .main-right .rating-right {

    display: inline-block;
  }

  #content .list .main-right .rating-right .rating-bg {
    width: 0.75rem;
    height: 0.15rem;
    position: relative;
    top:0.1rem;
    background: url(../assets/images/stars.png) no-repeat 0px 0px;
    display: block;
  }

  #content .list .main-right .rating-right .pingjia {
    font-style: normal;
    font-size: 0.14rem;
    color: #666;
  }
</style>
