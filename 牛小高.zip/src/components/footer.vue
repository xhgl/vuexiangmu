<template>
    <div>
      <!--底部栏-->
      <div class="nav">
        <ul>
          <li><router-link to="/coming">正在热映</router-link></li>
          <li><router-link to="/upcoming">即将上映</router-link></li>
          <li><router-link to="/ranking">排行榜</router-link></li>
          <li><router-link to="/my">我的</router-link></li>
        </ul>
      </div>
    </div>
</template>

<script>
    export default {}
</script>

<style>
  .nav{
    width: 7.5rem;
    height: 0.6rem;
    position: fixed;
    left: 50%;
    transform: translate(-50%);
    bottom: 0px;
    background: #9AB7DA;
    z-index: 1000;
  }
  .nav ul{
    width: 100%;
    height: 0.6rem;
    display: flex;
    z-index: 5;
  }
  .nav ul li{
    text-align: center;
    line-height: 0.6rem;
    flex: 1;
    border: 1px solid #ccc;
    border-bottom: none;
    border-left: none;
    float: left;
    font-size: 0.18rem;
  }
  .nav ul li:nth-child(4){
    border-right: none;
  }
  .nav ul li a{
    color: gray;
  }
</style>
