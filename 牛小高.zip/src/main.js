// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import vueRouter from "vue-router"
import upComing from "./components/upComing.vue"
import  Ranking from  "./components/ranking.vue"
import My from  "./components/my.vue"
import Coming from "./components/coming.vue"
import Detils from  "./components/detils.vue"

import Swiper  from  "vue-awesome-swiper"
import 'swiper/dist/css/swiper.css'
Vue.use(Swiper)

import "./assets/css/index.css"
import {show} from "./assets/js/adaptive";
show();

Vue.use(vueRouter)
let router = new vueRouter({
  routes:[
        {path:"/coming",component:Coming},
        {path:"/upcoming",component:upComing},
        {path:"/ranking",component:Ranking},
        {path:"/my",component:My},
        {path:"/detils/:cid",component:Detils,name:"detils"},
        {path:"/",component:Coming}
  ]
})
Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  components: { App },
  template: '<App/>',
  router,
})
