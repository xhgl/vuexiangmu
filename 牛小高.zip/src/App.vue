<template>
  <div id="app">

    <div ref="mybox" class="mybox" v-if="show">
        <img src="./assets/images/movie.png" alt="">
      <span @click="jump">跳过 {{num}}</span>
    </div>

    <router-view></router-view>

  </div>
</template>

<script>

export default {
  name: 'App',
  components: {

  },
  data(){
    return{
      num:5,
      show:"true",
    }
  },
  mounted () {
    this.init();
    this.time();
  },

  methods:{
    init() {
      const that = this;
//          this.$refs.mybox.style.transition = '2s';
      setTimeout(() => {
//            that.$refs.mybox.style.opacity = 0;
//        that.$refs.mybox.style.display = 'none';
        that.show = false;
        console.log(1);
      },5000)
    },
    time(){
      const that = this;
      let t=setInterval(function () {
        that.num--;
        console.log(that.num);
        if(that.num<1) {
         clearInterval(t);
        }
      },1000)
    },
    jump(){
      this.show = false;
    },
  }
}
</script>

<style>
#app{
  width: 100%;
  height: 100%;
}
  .mybox{
    width: 7.5rem;
    height: 100%;
    display: block;
    position: fixed;
    top:0;
    left: 50%;
    transform: translate(-50%);
    z-index: 1002;
    background: rosybrown;

  }
  .mybox img{
    width: 7.5rem;
    height:100%;
  }
  .mybox span{
    width: 60px;
    height: 30px;
    text-align: center;
    text-decoration: underline;
    color: deepskyblue;
    cursor: pointer;
    font-size: 18px;
    position: absolute;
    right: 6px;
    top:6px
  }



html ,body{
  width: 100%;
  height: 100%;
}



</style>
